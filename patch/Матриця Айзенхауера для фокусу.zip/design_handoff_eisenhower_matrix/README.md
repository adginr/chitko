# Handoff: Матриця Ейзенхауера (Eisenhower Matrix task tool)

## Overview
A full-screen 2×2 task-prioritization board (Eisenhower Matrix). Users organize tasks into four quadrants by urgency/importance, resize the quadrant split by dragging the crosshair dividers, move/edit/delete/star/complete tasks via a per-task menu, and attach Markdown notes to any task via a modal editor. A thin status bar at the bottom holds global actions (add task, focus list, done list).

## About the Design Files
The files in this bundle are **design references built in HTML** (a Claude "Design Component" runtime) — they demonstrate exact layout, interaction, and visual styling, but are **not production code to copy directly**. The task is to **recreate this design in the target codebase's existing environment** (React, Vue, Swift, etc.) using its established component patterns, state management, and styling approach — or, if no environment exists yet, choose the most appropriate stack and implement it there.

## Fidelity
**High-fidelity.** Colors, typography, spacing, and interaction behavior below should be treated as final and reproduced precisely.

## Files
- `Матриця Ейзенхауера (standalone).html` — self-contained, double-clickable bundle of the full working prototype (open directly in any browser, no server needed). Use this to click through every interaction.
- `Матриця Ейзенхауера.dc.html` — the original source (template + logic) if you want to trace exact class names/state shape referenced below.

## Layout

Full-viewport (`100vh` / `100vw`) column flex container, background `oklch(0.9 0.006 80)` (warm light gray, used as the 1px grid-line color throughout):

1. **Matrix grid** — flexes to fill remaining height. CSS Grid, 2 columns × 2 rows, `1px` gap (the gap IS the visible divider line, colored via the container background showing through). Column/row split is **dynamic and user-resizable** (see Interactions) — default 50/50, clamped 20–80%.
2. **Status bar** — fixed-height row, background `oklch(0.97 0.008 80)`, `padding: 6px clamp(14px,2vw,24px)`, `font-size: 12px`, `color: oklch(0.5 0.01 80)`.

No page title/header — the matrix fills the entire screen edge-to-edge.

### Quadrant order & meaning
Standard Eisenhower layout, fixed positions (not reorderable):
- **Top-left (q1)** — "Зробити зараз" (Do now) — терміново і важливо (urgent + important). Accent color `oklch(0.55 0.16 25)` (red).
- **Top-right (q2)** — "Запланувати" (Schedule) — важливо, не терміново (important, not urgent). Accent `oklch(0.5 0.11 250)` (blue).
- **Bottom-left (q3)** — "Делегувати" (Delegate) — терміново, не важливо (urgent, not important). Accent `oklch(0.68 0.13 80)` (amber).
- **Bottom-right (q4)** — "Колись" (Someday) — не важливо, не терміново (neither). Accent `oklch(0.58 0.015 260)` (slate).

These labels/colors are **not currently displayed as visible headers** in the UI (they were removed during iteration) — they exist only in the data model and inside the per-task "move to…" menu (see below), each option showing a directional arrow + the quadrant label. If the developer wants to reintroduce visible quadrant headers, use these exact labels/colors.

### Quadrant card
- `position: relative`, background `oklch(0.995 0.002 80)` (near-white) normally; while a dragged task hovers over it, background shifts to a faint tint of that quadrant's color at `oklch(0.955 0.012 <hue>)`.
- **Progressive dimming**: each quadrant has a fixed opacity applied regardless of drag state — q1: 100%, q2: 95%, q3: 85%, q4: 70%. This is a static per-quadrant visual weight, not related to focus mode.
- Padding `clamp(10px, 1.2vw, 14px)`, `overflow: auto` (scrolls internally if tasks overflow), flex column, `gap: 8px`.
- Empty state: dashed border placeholder, `1.5px dashed oklch(0.88 0.006 80)`, border-radius 10px, text "Перетягніть сюди завдання" in `oklch(0.65 0.01 80)`, `font-size: 13px`.
- Inline "add task" input appears at the bottom of the task list when adding (see Interactions), styled as a borderless input on `oklch(0.97 0.006 80)` background.

### Center crosshair (resize handles)
- A small filled circle, 6×6px, `border-radius: 50%`, `background: oklch(0.55 0.01 80)`, positioned exactly at the intersection of the two dividers (dynamic — follows the current split percentages).
- Two invisible drag handles overlay the dividers: a vertical strip (`9px` wide, `cursor: col-resize`) centered on the column split, and a horizontal strip (`9px` tall, `cursor: row-resize`) centered on the row split. Both span the full grid.

### Task card
Row, `display:flex; align-items:center; gap:10px`, background white, no border, `padding: 3px 5px`, `cursor: grab`, hover background `oklch(0.97 0.006 80)`. Draggable (native HTML5 drag-and-drop, `draggable="true"`).

Left to right:
1. **⋮ menu trigger** — `18×18px` clickable icon, `color: oklch(0.5 0.01 80)`, `font-size: 14px`. Opens the per-task dropdown (see below).
2. **Title** — `font-size: 14px; font-weight: 400; letter-spacing: -0.005em; line-height: 1.4; color: oklch(0.26 0.01 80)`. Clicking the title (not the menu) opens the notes modal. When the task is marked done: `color: oklch(0.65 0.01 80)` + `text-decoration: line-through`. When inline-editing (see below), this div is hidden and replaced by an `<input>` in the same position/font styling on a `oklch(0.97 0.006 80)` background.
3. **Focus star** (only rendered if task is starred) — `font-size: 11px; color: oklch(0.6 0.13 80)` — filled `★`.

### Per-task dropdown menu (opens below the ⋮ icon)
`position: absolute; top:100%; left:4px`, white background, `box-shadow: 0 2px 8px oklch(0 0 0 / 0.15)`, `min-width: 170px`, `z-index: 5`. Rows: `padding: 8px 12px; font-size: 13px`, hover `background: oklch(0.96 0.006 80)`.
1. **Move to [quadrant]** × 3 (all quadrants except current) — shows the target quadrant's directional arrow (↖↗↙↘) + label.
2. **У фокус / Прибрати з фокусу** (toggle star/focus) — top border separator `1px solid oklch(0.92 0.006 80)`.
3. **Редагувати** (inline-edit the title in place).
4. **Видалити** (delete) — `color: oklch(0.55 0.16 25)` (red).

### Inline title editing
Triggered by "Редагувати". Replaces the title div with a text `<input>`, same font styling, `autoFocus`, background `oklch(0.97 0.006 80)`. `Enter` commits, `Escape` cancels, blur commits (empty text is discarded, keeping the original).

### Add-task flow
- Status bar `+` button (plain text glyph, `color: oklch(0.5 0.01 80)`, hover darker) opens a quadrant picker dropdown (same visual style as the per-task menu: white bg, shadow, `min-width:170px`) listing all 4 quadrants with arrow + label.
- Selecting a quadrant reveals an inline text input at the bottom of that quadrant's task list (placeholder "нове завдання"). `Enter` submits and appends a new task with an auto-incrementing id; `Escape` or blur-with-empty-text cancels.

## Status bar (bottom, left → right)
1. **`+`** — opens the add-task quadrant picker (described above).
2. *(spacer — flex `margin-left:auto` pushes remaining items right)*
3. **Focus indicator**: a star glyph + count, e.g. `★ 3`. 
   - Clicking the **count** (or the row) opens a dropdown list of all starred/"focus" tasks (arrow + title per row; clicking a row un-stars that task).
   - Clicking the **star glyph itself** (separate click target, `stopPropagation`'d) toggles **Focus Mode**: when active, the star renders filled `★` in amber (`oklch(0.6 0.13 80)`); when inactive it renders outline `☆`. While Focus Mode is on, every task that is NOT starred drops to `opacity: 0.1` across all quadrants (starred tasks stay fully visible) — a visual "declutter to what matters" toggle.
4. **Done indicator**: `✓` + count of completed tasks. Clicking opens a dropdown list of completed tasks (strikethrough style); clicking a row un-marks it as done. *(Note: there is currently no visible UI control to mark a task done in this iteration — the checkbox affordance was removed. If completion is a required feature, the developer should add a visible done-toggle, e.g. back on the task row, since the data model (`task.done`) and all supporting UI (strikethrough title, done list, counter) are already fully wired.)*

## Notes modal (Markdown editor)
Triggered by clicking a task's title. Overlay: `position:fixed; inset:0; background: oklch(0 0 0 / 0.35)`, centers a panel via flex.

Panel: white, `width: min(640px, 90vw); height: min(70vh, 560px)`, `box-shadow: 0 8px 32px oklch(0 0 0 / 0.2)`, flex column.

**Header** (`padding: 14px 18px`, bottom border `1px solid oklch(0.92 0.006 80)`):
- Editable title `<input>` (bold, 15px, `oklch(0.24 0.01 80)`, borderless/transparent) — bound to the same task title as the card; saved on blur/Enter.
- Single toggle button, `padding: 5px 12px; font-size:12px; background: oklch(0.94 0.006 80)`, label flips between "Перегляд" (when in edit mode) and "Редагувати" (when in preview mode) — i.e. it always shows the destination state, not the current one.
- `✕` close button (`font-size:16px`, `color: oklch(0.5 0.01 80)`).

**Body** (flex, fills remaining height):
- **Edit mode** (default): a borderless `<textarea>`, monospace (`'SF Mono','IBM Plex Mono',monospace`), `13.5px`, `line-height:1.6`, `color: oklch(0.28 0.01 80)`, `padding:18px`, placeholder: "Нотатки у форматі Markdown: **жирний**, *курсив*, # заголовок, - список".
- **Preview mode**: renders the Markdown as HTML (headers `#`/`##`/`###` at 20/17/15px bold, `**bold**`, `*italic*`, `` `code` `` with a light gray background pill, `- `/`* ` bullet lists, blank lines as spacing). This is a **minimal custom Markdown subset** implemented by hand (not a library) — reimplement with any standard Markdown renderer (e.g. `marked`, `react-markdown`) in production; the exact subset needed is: h1–h3, bold, italic, inline code, unordered lists, paragraphs.

Closing the modal (✕, or clicking the overlay outside the panel) commits the current textarea content into that task's `notes` field. If a task has notes, no separate indicator is currently shown on the card (an earlier notes-dot indicator was removed) — notes are only visible by reopening the modal.

## Interactions & Behavior Summary
- **Drag-and-drop**: native HTML5 DnD. Dragging a task lowers its opacity to `0.35` in its origin position; dropping on a different quadrant moves it (removed from source array, appended to target array). Dropping back on its own quadrant is a no-op.
- **Resizable quadrants**: dragging either the vertical or horizontal divider live-updates the CSS grid template (`col%  (100-col)%` / same for rows), clamped between 20% and 80%. Implemented via `mousemove`/`mouseup` listeners on `window` while dragging, measuring against the grid container's bounding rect.
- **Focus Mode**: see status bar section above — a global dim-non-starred toggle.
- **All dropdowns** (per-task menu, add-picker, focus list, done list) close automatically when their action is taken; there is currently no explicit "click outside to close" handler for the per-task/add menus — verify this is intentional or add outside-click dismissal in production.

## State Management (reference shape)
```
quadrants: {
  q1: [{ id, title, done?, inAgenda?, notes? }, ...],
  q2: [...], q3: [...], q4: [...]
}
dragTaskId, dragFrom          // active drag
openMenuFor                   // task id with open ⋮ menu
addingTo, draftText           // inline add-task state
editingId, editText           // inline title-edit state
doneListOpen, agendaListOpen, addPickerOpen   // dropdown visibility
focusMode                     // boolean, dims non-starred tasks
modal: { key, taskId, title } | null, modalText, modalPreview, modalTitleText  // notes modal
colSplit, rowSplit            // 20–80, percentage grid split
```
Each task: `{ id: string, title: string, done?: boolean, inAgenda?: boolean, notes?: string }`.

## Design Tokens

**Colors** (all `oklch`, warm neutral base):
- Background/grid-line: `oklch(0.9 0.006 80)`
- Quadrant card (default): `oklch(0.995 0.002 80)`
- Status bar background: `oklch(0.97 0.008 80)`
- Dropdown/modal surface: `oklch(1 0 0)` (pure white)
- Primary text: `oklch(0.26 0.01 80)` / `oklch(0.24 0.01 80)` (headers/titles)
- Secondary/muted text: `oklch(0.5 0.01 80)` / `oklch(0.55 0.01 80)` / `oklch(0.65 0.01 80)`
- Hover surface: `oklch(0.96 0.006 80)` / `oklch(0.97 0.006 80)`
- Divider lines: `oklch(0.92 0.006 80)`
- Quadrant accents: q1 red `oklch(0.55 0.16 25)`, q2 blue `oklch(0.5 0.11 250)`, q3 amber `oklch(0.68 0.13 80)`, q4 slate `oklch(0.58 0.015 260)`
- Focus star (active): `oklch(0.6 0.13 80)`
- Done accent: `oklch(0.5 0.11 250)`
- Destructive (delete): `oklch(0.55 0.16 25)`
- Modal overlay: `oklch(0 0 0 / 0.35)`

**Typography**: IBM Plex Sans (weights 400/500/600/700), loaded from Google Fonts. Task text 14px/400, menu items 13px, status bar 12px, modal title 15px/600, modal body 14px, textarea 13.5px monospace.

**Spacing**: quadrant padding `clamp(10px,1.2vw,14px)`, task row padding `3px 5px`, dropdown row padding `8px 12px`, status bar padding `6px clamp(14px,2vw,24px)`, 1px grid gaps throughout.

**Shadows**: dropdowns `0 2px 8px oklch(0 0 0 / 0.15)` (or `0 -2px 8px` for upward-opening ones), modal `0 8px 32px oklch(0 0 0 / 0.2)`.

**No border-radius** used anywhere in the current design (fully rectangular, flat) except the empty-state dashed placeholder (`10px`) and the resize-handle dot (`50%`).

## Assets
No images/icons/illustrations — all iconography is Unicode glyphs (⋮ ✓ ★ ☆ ✎ ✕ ↖ ↗ ↙ ↘) styled with CSS color/size, not an icon font or SVG set. Reimplement with the target codebase's icon system if Unicode glyphs aren't desired in production (e.g. Lucide/Heroicons for menu-dots, star, checkmark, close, and directional arrows).

## Open Questions for Product/Design
1. There's currently no visible way to mark a task "done" from the UI (only via the wired-but-unexposed toggle) — confirm whether to add a checkbox back to the task row.
2. Quadrant header labels/criteria text are not visibly shown on screen — confirm whether headers should be reintroduced (data model already supports it).
3. Persistence: this prototype holds all state in memory only (resets on reload). Confirm whether production needs localStorage/backend persistence.
